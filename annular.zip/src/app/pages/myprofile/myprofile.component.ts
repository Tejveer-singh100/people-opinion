import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, UntypedFormBuilder, Validators} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { AppSettings } from 'src/app/app.settings';
import { Settings } from 'src/app/app.settings.model';
import { TablesService, Element } from './tables.service';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.scss'],
  encapsulation: ViewEncapsulation.None  
})
export class MyprofileComponent implements OnInit {
  public personalForm:UntypedFormGroup;
  public changepassword:UntypedFormGroup;
  
  public salutations = [
    { id: 1, name: 'Mr' },
    { id: 2, name: 'Mrs' } 
  ];
  public genders = [
    { id: 1, name: 'Male' },
    { id: 2, name: 'Female' } 
  ];
  public countries = [
    { id: 1, name: 'USA' },
    { id: 2, name: 'Canada' },
    { id: 3, name: 'Mexico' },
    { id: 4, name: 'UK' },
    { id: 5, name: 'France' },
    { id: 6, name: 'Italy' } 
  ];
  public states = [
    { id: 1, name: 'Arkansas' },
    { id: 2, name: 'Texas' },
    { id: 3, name: 'California' },
    { id: 4, name: 'Florida' },
    { id: 5, name: 'Other' } 
  ];
  public surveyhistory:UntypedFormGroup;
  public days = [
    { id: 1, name: 'Last 30days' },
    { id: 2, name: 'Last 90days' },
    { id: 3, name: 'Last 180days' }  
  ];
  public displayedColumns = ['position', 'survey', 'approvedpoint', 'date'];
  public dataSource: any;
  public settings: Settings;
  constructor(public appSettings:AppSettings, private tablesService:TablesService, private formBuilder: UntypedFormBuilder) { 
    this.settings = this.appSettings.settings; 
    this.dataSource = new MatTableDataSource<Element>(this.tablesService.getData());
  }

  ngOnInit() {
    this.personalForm = this.formBuilder.group({
      'salutation': [''],
      'firstname': ['', Validators.required],
      'lastname': ['', Validators.required],
      'gender': [''],
      'email': ['', Validators.compose([Validators.required, emailValidator])],
      'phone': ['', Validators.required],
      'zipcode': ['', Validators.required],
      'country': ['', Validators.required],
      'state' : [''],
      'address' : ['']
    });
  }

  public onSubmit(values:Object):void {
      if (this.personalForm.valid) {
          // this.router.navigate(['pages/dashboard']);
      }
  }   
}
export function emailValidator(control: UntypedFormControl): {[key: string]: any} {
  var emailRegexp = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;    
  if (control.value && !emailRegexp.test(control.value)) {
      return {invalidEmail: true};
  }
}
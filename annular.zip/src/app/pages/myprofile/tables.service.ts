import { Injectable } from '@angular/core';

export interface Element {
  survey: string;
  position: number;
  approvedpoint: number;
  date: string;
}

const data: Element[] = [
  {position: 1, survey: 'Hydrogen', approvedpoint: 1.0079, date: 'H'},
  {position: 2, survey: 'Helium', approvedpoint: 4.0026, date: 'He'},
  {position: 3, survey: 'Lithium', approvedpoint: 6.941, date: 'Li'}  
];


@Injectable()
export class TablesService {

  constructor() { }

  getData(){
    return data;
  }
}

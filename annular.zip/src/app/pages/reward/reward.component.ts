import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AppSettings } from 'src/app/app.settings';
import { Settings } from 'd:/AngularMaterial/annular/src/app/app.settings.model';

@Component({
  selector: 'app-reward',
  templateUrl: './reward.component.html',
  styleUrls: ['./reward.component.scss']
})
export class RewardComponent implements OnInit {
  public giftcards = [
    { name: 'Amazon Pay Card', desc: "Lorem ipsum dolor sit amet...", point: "500 Points", image: 'assets/img/giftCard/amazon.jpg' },
    { name: 'Flipkart.com', desc: "Lorem ipsum dolor sit amet...", point: "300 Points",  image: 'assets/img/giftCard/flipkart.png' },
    { name: 'Westside', desc: "Lorem ipsum dolor sit amet...", point: "400 Points",  image: 'assets/img/giftCard/westside.jpg'  }, 
    { name: 'Amazon Pay Card', desc: "Lorem ipsum dolor sit amet...", point: "500 Points", image: 'assets/img/giftCard/amazon.jpg' },
    { name: 'Flipkart.com', desc: "Lorem ipsum dolor sit amet...", point: "300 Points",  image: 'assets/img/giftCard/flipkart.png' },
    { name: 'Westside', desc: "Lorem ipsum dolor sit amet...", point: "400 Points",  image: 'assets/img/giftCard/westside.jpg'  },    
  ]
  public animal: string;
  public name1: string;
  public settings: Settings;
  static settings: import("d:/AngularMaterial/annular/src/app/app.settings.model").Settings;
  constructor(public appSettings:AppSettings, public dialog: MatDialog) {
    RewardComponent.settings = this.appSettings.settings; 
  }
  ngOnInit(): void {
   // throw new Error('Method not implemented.');
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(giftcarddailog, {
      data: { name: this.name1, animal: this.animal }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }
}
@Component({
  selector: 'giftcarddailog',
  templateUrl: 'giftcarddailog.html',
})
export class giftcarddailog {

  constructor(
    public dialogRef: MatDialogRef<giftcarddailog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}

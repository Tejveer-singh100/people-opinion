


import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-surveys',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.scss']
})
export class SurveyComponent implements OnInit {
  public surveys = [
    { name: 'survey Name 1', desc: "Business & Employment" },
    { name: 'survey Name 2', desc: "Automobile" },
    { name: 'survey Name 3', desc: "Food and Health" },
    { name: 'survey Name 4', desc: "Electronics" }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
